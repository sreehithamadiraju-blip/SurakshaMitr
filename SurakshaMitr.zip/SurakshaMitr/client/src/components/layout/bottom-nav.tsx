import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Home, Map, AlertTriangle, User } from "lucide-react";

const navItems = [
  { path: "/home", icon: Home, label: "Home" },
  { path: "/map", icon: Map, label: "Map" },
  { path: "/alerts", icon: AlertTriangle, label: "Alerts", badge: 3 },
  { path: "/profile", icon: User, label: "Profile" },
];

export default function BottomNav() {
  const [location, navigate] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Button
              key={item.path}
              onClick={() => navigate(item.path)}
              variant="ghost"
              className={`flex flex-col items-center p-2 h-auto relative ${
                isActive 
                  ? "text-primary" 
                  : "text-muted-foreground hover:text-primary"
              } transition-colors`}
              data-testid={`nav-tab-${item.label.toLowerCase()}`}
            >
              <Icon className="text-xl mb-1" size={24} />
              <span className="text-xs font-medium">{item.label}</span>
              {item.badge && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 w-4 h-4 text-xs flex items-center justify-center p-0 bg-accent text-accent-foreground"
                >
                  {item.badge}
                </Badge>
              )}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
