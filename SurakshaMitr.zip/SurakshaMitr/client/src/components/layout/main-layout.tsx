import { useEffect } from "react";
import { useLocation } from "wouter";
import { getStoredUser } from "@/lib/storage";
import BottomNav from "./bottom-nav";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Check if user is registered, redirect to welcome if not
    const user = getStoredUser();
    if (!user) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background">
      <main className="pb-16">
        {children}
      </main>
      <BottomNav />
    </div>
  );
}
