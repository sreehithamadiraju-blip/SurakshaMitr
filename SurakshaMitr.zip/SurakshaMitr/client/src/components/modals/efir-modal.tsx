import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, Edit, X } from "lucide-react";
import type { EFIR } from "@shared/schema";

interface EFIRModalProps {
  efir: EFIR;
  onClose: () => void;
}

export default function EFIRModal({ efir, onClose }: EFIRModalProps) {
  const handleDownload = () => {
    // Create a blob with the E-FIR content
    const blob = new Blob([efir.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    
    // Create download link
    const a = document.createElement('a');
    a.href = url;
    a.download = `${efir.firNumber}-EFIR.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" data-testid="modal-efir">
      <Card className="m-4 max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="text-xl font-bold">Generated E-FIR</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              AI-Generated Electronic First Information Report
            </p>
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-close-efir-modal"
          >
            <X size={20} />
          </Button>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-hidden p-6 pt-2">
          <ScrollArea className="h-full">
            <div className="prose prose-sm max-w-none" data-testid="text-efir-content">
              {/* Convert markdown-style content to JSX */}
              <div dangerouslySetInnerHTML={{ 
                __html: efir.content
                  .replace(/# (.*)/g, '<h1>$1</h1>')
                  .replace(/## (.*)/g, '<h2>$1</h2>')
                  .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                  .replace(/\n/g, '<br>')
              }} />
            </div>
          </ScrollArea>
        </CardContent>
        
        <div className="p-6 border-t border-border flex gap-3">
          <Button 
            onClick={handleDownload}
            className="flex-1"
            data-testid="button-download-efir"
          >
            <Download className="mr-2" size={16} />
            Download PDF
          </Button>
          <Button 
            variant="ghost"
            className="flex-1"
            data-testid="button-edit-efir"
          >
            <Edit className="mr-2" size={16} />
            Edit E-FIR
          </Button>
        </div>
      </Card>
    </div>
  );
}
