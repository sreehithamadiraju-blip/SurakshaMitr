import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Phone, MessageSquare, X } from "lucide-react";
import { getEmergencyNumber } from "@/lib/emergency-numbers";
import { getStoredUser } from "@/lib/storage";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SOSModalProps {
  serviceType: string;
  onClose: () => void;
}

export default function SOSModal({ serviceType, onClose }: SOSModalProps) {
  const user = getStoredUser();
  const { toast } = useToast();

  const emergencyInfo = getEmergencyNumber(serviceType);

  const logSOSMutation = useMutation({
    mutationFn: async (action: string) => {
      if (!user) throw new Error("User not found");
      
      // Get current location if available
      return new Promise<void>((resolve) => {
        navigator.geolocation?.getCurrentPosition(
          async (position) => {
            try {
              await apiRequest("POST", "/api/sos-alerts", {
                userId: user.id,
                serviceType,
                location: `${position.coords.latitude}, ${position.coords.longitude}`,
                coordinates: {
                  lat: position.coords.latitude,
                  lng: position.coords.longitude,
                },
                response: `User initiated ${action} to ${emergencyInfo.number}`,
              });
              resolve();
            } catch (error) {
              resolve(); // Don't fail the SOS action if logging fails
            }
          },
          async () => {
            try {
              await apiRequest("POST", "/api/sos-alerts", {
                userId: user.id,
                serviceType,
                location: "Location unavailable",
                response: `User initiated ${action} to ${emergencyInfo.number}`,
              });
              resolve();
            } catch (error) {
              resolve(); // Don't fail the SOS action if logging fails
            }
          }
        );
      });
    },
  });

  const handleCall = () => {
    logSOSMutation.mutate("call");
    window.open(`tel:${emergencyInfo.number}`, '_self');
    onClose();
    
    toast({
      title: "Emergency Call Initiated",
      description: `Calling ${emergencyInfo.service} at ${emergencyInfo.number}`,
    });
  };

  const handleSMS = () => {
    logSOSMutation.mutate("SMS");
    const message = encodeURIComponent(
      `EMERGENCY: This is an automated message from SurakshaMitr. I need immediate assistance. Tourist ID: ${user?.digitalId || 'Unknown'}`
    );
    window.open(`sms:${emergencyInfo.number}?body=${message}`, '_self');
    onClose();
    
    toast({
      title: "Emergency SMS Sent",
      description: `SMS sent to ${emergencyInfo.service} at ${emergencyInfo.number}`,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" data-testid="modal-sos">
      <Card className="m-4 max-w-sm w-full">
        <CardContent className="p-6">
          <div className="text-center mb-4">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="text-red-500" size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2" data-testid="text-sos-service-title">Emergency Service</h3>
            <p className="text-muted-foreground" data-testid="text-sos-service-description">
              {emergencyInfo.service}
            </p>
            <p className="text-lg font-semibold text-primary mt-2" data-testid="text-sos-number">
              {emergencyInfo.number}
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleCall}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center"
              data-testid="button-call-emergency"
            >
              <Phone className="mr-2" size={20} />
              Call Now
            </Button>
            
            <Button
              onClick={handleSMS}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center"
              data-testid="button-sms-emergency"
            >
              <MessageSquare className="mr-2" size={20} />
              Send SMS
            </Button>
            
            <Button
              onClick={onClose}
              variant="ghost"
              className="w-full bg-muted text-muted-foreground py-3 px-4 rounded-lg font-medium"
              data-testid="button-cancel-sos"
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
