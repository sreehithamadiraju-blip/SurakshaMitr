interface EmergencyService {
  number: string;
  service: string;
  description: string;
}

const emergencyNumbers: Record<string, EmergencyService> = {
  police: {
    number: "100",
    service: "Police Emergency Services",
    description: "Immediate police assistance for crimes, accidents, and security issues"
  },
  ambulance: {
    number: "102", 
    service: "Medical Emergency / Ambulance",
    description: "Emergency medical services and ambulance dispatch"
  },
  fire: {
    number: "101",
    service: "Fire Department Emergency", 
    description: "Fire emergency services and rescue operations"
  },
  women: {
    number: "1091",
    service: "Women & Child Helpline",
    description: "Specialized support services for women and children in distress"
  },
};

export function getEmergencyNumber(serviceType: string): EmergencyService {
  return emergencyNumbers[serviceType] || emergencyNumbers.police;
}

export function getAllEmergencyNumbers(): Record<string, EmergencyService> {
  return emergencyNumbers;
}
