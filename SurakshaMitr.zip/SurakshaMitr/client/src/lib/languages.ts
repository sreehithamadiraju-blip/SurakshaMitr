export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export const LANGUAGES: Language[] = [
  {
    code: "en",
    name: "English", 
    nativeName: "English",
    flag: "🇮🇳"
  },
  {
    code: "hi",
    name: "हिन्दी (Hindi)",
    nativeName: "हिन्दी", 
    flag: "🇮🇳"
  },
  {
    code: "bn", 
    name: "বাংলা (Bengali)",
    nativeName: "বাংলা",
    flag: "🇮🇳"
  },
  {
    code: "ta",
    name: "தமிழ் (Tamil)", 
    nativeName: "தமிழ்",
    flag: "🇮🇳"
  },
  {
    code: "te",
    name: "తెలుగు (Telugu)", 
    nativeName: "తెలుగు",
    flag: "🇮🇳"
  },
  {
    code: "mr",
    name: "मराठी (Marathi)", 
    nativeName: "मराठी",
    flag: "🇮🇳"
  },
  {
    code: "gu",
    name: "ગુજરાતી (Gujarati)", 
    nativeName: "ગુજરાતી",
    flag: "🇮🇳"
  },
  {
    code: "kn",
    name: "ಕನ್ನಡ (Kannada)", 
    nativeName: "ಕನ್ನಡ",
    flag: "🇮🇳"
  },
  {
    code: "ml",
    name: "മലയാളം (Malayalam)", 
    nativeName: "മലയാളം",
    flag: "🇮🇳"
  },
  {
    code: "pa",
    name: "ਪੰਜਾਬੀ (Punjabi)", 
    nativeName: "ਪੰਜਾਬੀ",
    flag: "🇮🇳"
  },
];

export function getLanguage(code: string): Language | undefined {
  return LANGUAGES.find(lang => lang.code === code);
}
