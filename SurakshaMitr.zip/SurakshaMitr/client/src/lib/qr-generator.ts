// QR Code generation utility using a lightweight library approach
// Since we can't include binary assets, we'll use a web-based QR code generation service

export interface QRCodeOptions {
  size?: number;
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
  foregroundColor?: string;
  backgroundColor?: string;
}

export async function generateQRCode(
  data: string, 
  options: QRCodeOptions = {}
): Promise<string> {
  const {
    size = 256,
    errorCorrectionLevel = 'M',
    foregroundColor = '000000',
    backgroundColor = 'ffffff'
  } = options;

  try {
    // Use QR-Server API for QR code generation
    const params = new URLSearchParams({
      data: encodeURIComponent(data),
      size: `${size}x${size}`,
      ecc: errorCorrectionLevel,
      color: foregroundColor,
      bgcolor: backgroundColor,
      format: 'png'
    });

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?${params.toString()}`;
    
    // Validate that the URL is accessible
    const response = await fetch(qrUrl, { method: 'HEAD' });
    if (!response.ok) {
      throw new Error('QR code generation service unavailable');
    }
    
    return qrUrl;
  } catch (error) {
    console.error('QR code generation failed:', error);
    
    // Fallback: Generate a simple data URL with base64 encoded SVG
    return generateFallbackQR(data, size);
  }
}

function generateFallbackQR(data: string, size: number): string {
  // Create a simple SVG-based QR code pattern as fallback
  const modules = 21; // Standard QR code size
  const moduleSize = size / modules;
  
  // Generate a pseudo-random pattern based on data hash
  const hash = simpleHash(data);
  let pattern = '';
  
  for (let y = 0; y < modules; y++) {
    for (let x = 0; x < modules; x++) {
      const isBlack = (hash + x * 7 + y * 11) % 3 === 0;
      if (isBlack) {
        pattern += `<rect x="${x * moduleSize}" y="${y * moduleSize}" width="${moduleSize}" height="${moduleSize}" fill="#000"/>`;
      }
    }
  }
  
  const svg = `
    <svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="#fff"/>
      ${pattern}
      <!-- Corner markers -->
      <rect x="0" y="0" width="${moduleSize * 7}" height="${moduleSize * 7}" fill="none" stroke="#000" stroke-width="2"/>
      <rect x="${moduleSize * 2}" y="${moduleSize * 2}" width="${moduleSize * 3}" height="${moduleSize * 3}" fill="#000"/>
      
      <rect x="${size - moduleSize * 7}" y="0" width="${moduleSize * 7}" height="${moduleSize * 7}" fill="none" stroke="#000" stroke-width="2"/>
      <rect x="${size - moduleSize * 5}" y="${moduleSize * 2}" width="${moduleSize * 3}" height="${moduleSize * 3}" fill="#000"/>
      
      <rect x="0" y="${size - moduleSize * 7}" width="${moduleSize * 7}" height="${moduleSize * 7}" fill="none" stroke="#000" stroke-width="2"/>
      <rect x="${moduleSize * 2}" y="${size - moduleSize * 5}" width="${moduleSize * 3}" height="${moduleSize * 3}" fill="#000"/>
    </svg>
  `;
  
  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

function simpleHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash);
}

export async function generateDigitalIDQR(user: {
  digitalId: string;
  name: string;
  mobile: string;
  idType: string;
  isVerified?: boolean;
}): Promise<string> {
  const qrData = {
    type: 'DIGITAL_TOURIST_ID',
    digitalId: user.digitalId,
    name: user.name,
    mobile: user.mobile,
    idType: user.idType,
    verified: user.isVerified || false,
    issuer: 'SurakshaMitr',
    timestamp: new Date().toISOString()
  };

  return generateQRCode(JSON.stringify(qrData), {
    size: 256,
    errorCorrectionLevel: 'H',
    foregroundColor: '2979FF', // Primary blue color
    backgroundColor: 'FFFFFF'
  });
}

export function parseDigitalIDQR(qrData: string): any {
  try {
    const parsed = JSON.parse(qrData);
    
    if (parsed.type !== 'DIGITAL_TOURIST_ID') {
      throw new Error('Invalid QR code type');
    }
    
    // Validate required fields
    const requiredFields = ['digitalId', 'name', 'mobile', 'idType'];
    for (const field of requiredFields) {
      if (!parsed[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }
    
    return parsed;
  } catch (error) {
    throw new Error('Invalid Digital Tourist ID QR code');
  }
}
