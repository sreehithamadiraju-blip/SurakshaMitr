import type { User } from "@shared/schema";

const USER_STORAGE_KEY = "surakshaMitr_user";

export function storeUser(user: User): void {
  try {
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
  } catch (error) {
    console.error("Failed to store user data:", error);
  }
}

export function getStoredUser(): User | null {
  try {
    const userData = localStorage.getItem(USER_STORAGE_KEY);
    if (!userData) return null;
    
    const parsedUser = JSON.parse(userData);
    
    // Validate that the stored data has required fields
    if (!parsedUser.id || !parsedUser.digitalId || !parsedUser.name) {
      clearStoredUser();
      return null;
    }
    
    return parsedUser as User;
  } catch (error) {
    console.error("Failed to retrieve user data:", error);
    clearStoredUser();
    return null;
  }
}

export function updateStoredUser(updates: Partial<User>): void {
  try {
    const currentUser = getStoredUser();
    if (!currentUser) {
      console.error("No user found to update");
      return;
    }
    
    const updatedUser = { ...currentUser, ...updates };
    storeUser(updatedUser);
  } catch (error) {
    console.error("Failed to update user data:", error);
  }
}

export function clearStoredUser(): void {
  try {
    localStorage.removeItem(USER_STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear user data:", error);
  }
}

export function isUserRegistered(): boolean {
  const user = getStoredUser();
  return user !== null && user.isVerified === true;
}

// Additional utility functions for managing user preferences
export function storeUserPreference(key: string, value: any): void {
  try {
    const prefKey = `surakshaMitr_pref_${key}`;
    localStorage.setItem(prefKey, JSON.stringify(value));
  } catch (error) {
    console.error(`Failed to store preference ${key}:`, error);
  }
}

export function getUserPreference(key: string, defaultValue: any = null): any {
  try {
    const prefKey = `surakshaMitr_pref_${key}`;
    const storedValue = localStorage.getItem(prefKey);
    
    if (!storedValue) return defaultValue;
    return JSON.parse(storedValue);
  } catch (error) {
    console.error(`Failed to retrieve preference ${key}:`, error);
    return defaultValue;
  }
}

export function clearUserPreferences(): void {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith('surakshaMitr_pref_')) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error("Failed to clear user preferences:", error);
  }
}
