import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  AlertTriangle, 
  Shield, 
  Lightbulb, 
  Car, 
  MapPin,
  Clock,
  Info
} from "lucide-react";
import { Alert } from "@shared/schema";

type AlertFilter = "all" | "scam_warning" | "police_bulletin" | "safety_tip" | "traffic_update";

const alertIcons = {
  scam_warning: AlertTriangle,
  police_bulletin: Shield,
  safety_tip: Lightbulb,
  traffic_update: Car,
};

const alertColors = {
  scam_warning: { bg: "border-l-accent", badge: "bg-accent/10 text-accent", icon: "text-accent" },
  police_bulletin: { bg: "border-l-red-500", badge: "bg-red-100 text-red-800", icon: "text-red-500" },
  safety_tip: { bg: "border-l-green-500", badge: "bg-green-100 text-green-800", icon: "text-green-500" },
  traffic_update: { bg: "border-l-blue-500", badge: "bg-blue-100 text-blue-800", icon: "text-blue-500" },
};

const alertLabels = {
  scam_warning: "SCAM WARNING",
  police_bulletin: "POLICE BULLETIN", 
  safety_tip: "SAFETY TIP",
  traffic_update: "TRAFFIC UPDATE",
};

const priorityLabels = {
  low: "Low Priority",
  medium: "Medium Priority", 
  high: "High Priority",
  critical: "Critical",
};

function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  return `${Math.floor(diffInSeconds / 86400)} days ago`;
}

export default function Alerts() {
  const [activeFilter, setActiveFilter] = useState<AlertFilter>("all");

  const { data: alertsData, isLoading } = useQuery({
    queryKey: ["/api/alerts"],
  });

  const alerts = alertsData?.alerts || [] as Alert[];

  const filteredAlerts = alerts.filter(alert => 
    activeFilter === "all" || alert.type === activeFilter
  );

  const filterTabs = [
    { key: "all" as AlertFilter, label: "All Alerts" },
    { key: "scam_warning" as AlertFilter, label: "Scam Warnings" },
    { key: "police_bulletin" as AlertFilter, label: "Police Bulletins" },
  ];

  return (
    <div className="p-6 pb-20">
      <h2 className="text-2xl font-bold mb-6" data-testid="text-alerts-title">Safety Alerts</h2>
      
      {/* Alert Filter Tabs */}
      <div className="flex bg-muted rounded-lg p-1 mb-6">
        {filterTabs.map((tab) => (
          <Button
            key={tab.key}
            onClick={() => setActiveFilter(tab.key)}
            variant="ghost"
            className={`flex-1 py-2 px-4 rounded-md font-medium text-sm transition-colors ${
              activeFilter === tab.key
                ? "bg-primary text-primary-foreground" 
                : "text-muted-foreground hover:bg-background"
            }`}
            data-testid={`button-filter-${tab.key}`}
          >
            {tab.label}
          </Button>
        ))}
      </div>
      
      {/* Alert Cards */}
      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-4 bg-muted rounded mb-2" />
                <div className="h-6 bg-muted rounded mb-3" />
                <div className="h-12 bg-muted rounded mb-3" />
                <div className="h-4 bg-muted rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredAlerts.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground" data-testid="text-no-alerts">No alerts available at the moment.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredAlerts.map((alert) => {
            const Icon = alertIcons[alert.type as keyof typeof alertIcons];
            const colors = alertColors[alert.type as keyof typeof alertColors];
            
            return (
              <Card key={alert.id} className={`border-l-4 ${colors.bg}`} data-testid={`card-alert-${alert.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center">
                      {Icon && <Icon className={`mr-2 ${colors.icon}`} size={16} />}
                      <Badge variant="secondary" className={`font-semibold text-xs ${colors.badge}`}>
                        {alertLabels[alert.type as keyof typeof alertLabels]}
                      </Badge>
                    </div>
                    <span className="text-xs text-muted-foreground" data-testid={`text-alert-time-${alert.id}`}>
                      {alert.createdAt ? formatTimeAgo(new Date(alert.createdAt)) : 'Unknown time'}
                    </span>
                  </div>
                  
                  <h3 className="font-semibold mb-2" data-testid={`text-alert-title-${alert.id}`}>
                    {alert.title}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground mb-3" data-testid={`text-alert-description-${alert.id}`}>
                    {alert.description}
                  </p>
                  
                  <div className="flex items-center text-xs text-muted-foreground">
                    {alert.location ? (
                      <>
                        <MapPin className="mr-1" size={12} />
                        <span>{alert.location}</span>
                        <span className="mx-2">•</span>
                      </>
                    ) : (
                      <>
                        <Info className="mr-1" size={12} />
                        <span>General Advisory</span>
                        <span className="mx-2">•</span>
                      </>
                    )}
                    <span data-testid={`text-alert-priority-${alert.id}`}>
                      {priorityLabels[alert.priority as keyof typeof priorityLabels] || alert.priority}
                    </span>
                    {alert.validUntil && (
                      <>
                        <span className="mx-2">•</span>
                        <Clock className="mr-1" size={12} />
                        <span>Valid until {new Date(alert.validUntil).toLocaleDateString()}</span>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
