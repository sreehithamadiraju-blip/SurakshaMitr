import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  AlertTriangle, 
  MapPin, 
  FileText, 
  RefreshCw, 
  Bot,
  Download,
  Edit,
  Smartphone
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import EFIRModal from "@/components/modals/efir-modal";
import type { InsertEFIR, SOSAlert } from "@shared/schema";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showEFIRModal, setShowEFIRModal] = useState(false);
  const [generatedEFIR, setGeneratedEFIR] = useState<any>(null);

  const [efirForm, setEfirForm] = useState<InsertEFIR>({
    touristName: "",
    touristId: "",
    incidentLocation: "",
    incidentDateTime: new Date(),
    incidentSummary: "",
    officerName: "",
    officerBadge: "",
    policeStation: "",
    status: "draft",
  });

  const { data: sosAlertsData } = useQuery({
    queryKey: ["/api/sos-alerts"],
  });

  const sosAlerts = sosAlertsData?.alerts || [] as SOSAlert[];

  const generateEFIRMutation = useMutation({
    mutationFn: async (data: InsertEFIR) => {
      const response = await apiRequest("POST", "/api/efirs", data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setGeneratedEFIR(data.efir);
        setShowEFIRModal(true);
        toast({
          title: "E-FIR Generated Successfully",
          description: "The AI has generated a structured E-FIR based on the incident details.",
        });
        // Reset form
        setEfirForm({
          touristName: "",
          touristId: "",
          incidentLocation: "",
          incidentDateTime: new Date(),
          incidentSummary: "",
          officerName: "",
          officerBadge: "",
          policeStation: "",
          status: "draft",
        });
      } else {
        throw new Error(data.error);
      }
    },
    onError: (error) => {
      toast({
        title: "E-FIR Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleEFIRSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateEFIRMutation.mutate(efirForm);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-red-100 text-red-800";
      case "in_progress": return "bg-yellow-100 text-yellow-800"; 
      case "resolved": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getServiceColor = (serviceType: string) => {
    switch (serviceType) {
      case "police": return "bg-red-100 text-red-800";
      case "ambulance": return "bg-orange-100 text-orange-800";
      case "fire": return "bg-orange-100 text-orange-800"; 
      case "women": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-secondary p-6">
      {/* Dashboard Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-primary" data-testid="text-dashboard-title">SurakshaMitr</h1>
          <p className="text-muted-foreground">Administrative Dashboard</p>
        </div>
        <Button 
          onClick={() => navigate("/home")}
          className="bg-primary hover:bg-primary/90"
          data-testid="button-switch-mobile"
        >
          <Smartphone className="mr-2" size={16} />
          Switch to Mobile
        </Button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Users</p>
                <p className="text-2xl font-bold text-primary" data-testid="text-active-users">1,247</p>
              </div>
              <Users className="text-primary" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">SOS Alerts Today</p>
                <p className="text-2xl font-bold text-accent" data-testid="text-sos-alerts-today">
                  {sosAlerts.filter(alert => {
                    const today = new Date().toDateString();
                    return new Date(alert.createdAt!).toDateString() === today;
                  }).length}
                </p>
              </div>
              <AlertTriangle className="text-accent" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Risk Areas</p>
                <p className="text-2xl font-bold text-red-500" data-testid="text-risk-areas">5</p>
              </div>
              <MapPin className="text-red-500" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">E-FIRs Generated</p>
                <p className="text-2xl font-bold text-green-500" data-testid="text-efirs-generated">89</p>
              </div>
              <FileText className="text-green-500" size={32} />
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Real-time Tourist Monitoring Map */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Tourist Location Monitor</CardTitle>
            <Button variant="ghost" size="sm" data-testid="button-refresh-map">
              <RefreshCw className="mr-1" size={16} />
              Refresh
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-96 bg-gray-200 rounded-lg relative overflow-hidden">
              {/* Simulated map with overlays */}
              <div 
                className="w-full h-full bg-cover bg-center"
                style={{
                  backgroundImage: "url('https://images.unsplash.com/photo-1566552881560-0be862a7c445?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600')"
                }}
              >
                {/* Heat map overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-red-500/20 rounded-lg" />
                
                {/* Tourist markers */}
                <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-primary rounded-full shadow-lg animate-pulse" />
                <div className="absolute top-1/2 right-1/3 w-3 h-3 bg-primary rounded-full shadow-lg animate-pulse" />
                <div className="absolute bottom-1/3 left-1/2 w-3 h-3 bg-primary rounded-full shadow-lg animate-pulse" />
                
                {/* SOS Alert marker */}
                <div className="absolute top-1/3 right-1/4 w-4 h-4 bg-red-500 rounded-full shadow-lg animate-ping" />
                <div className="absolute top-1/3 right-1/4 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">!</span>
                </div>
                
                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white/90 rounded-lg p-2 text-xs">
                  <div className="flex items-center mb-1">
                    <div className="w-2 h-2 bg-primary rounded-full mr-2" />
                    <span>Active Users</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-red-500 rounded-full mr-2" />
                    <span>SOS Alerts</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* AI-Powered E-FIR Generator */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">AI E-FIR Generator</CardTitle>
            <p className="text-sm text-muted-foreground">Generate structured Electronic First Information Reports</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleEFIRSubmit} className="space-y-4">
              <div>
                <Label htmlFor="tourist-name">Tourist Name</Label>
                <Input
                  id="tourist-name"
                  value={efirForm.touristName}
                  onChange={(e) => setEfirForm({ ...efirForm, touristName: e.target.value })}
                  placeholder="Enter tourist name"
                  required
                  data-testid="input-tourist-name"
                />
              </div>
              
              <div>
                <Label htmlFor="tourist-id">Tourist ID</Label>
                <Input
                  id="tourist-id"
                  value={efirForm.touristId}
                  onChange={(e) => setEfirForm({ ...efirForm, touristId: e.target.value })}
                  placeholder="Enter digital ID or document number"
                  required
                  data-testid="input-tourist-id"
                />
              </div>
              
              <div>
                <Label htmlFor="incident-summary">Incident Summary</Label>
                <Textarea
                  id="incident-summary"
                  value={efirForm.incidentSummary}
                  onChange={(e) => setEfirForm({ ...efirForm, incidentSummary: e.target.value })}
                  placeholder="Describe the incident in detail..."
                  rows={4}
                  className="resize-none"
                  required
                  data-testid="textarea-incident-summary"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="incident-location">Location</Label>
                  <Input
                    id="incident-location"
                    value={efirForm.incidentLocation}
                    onChange={(e) => setEfirForm({ ...efirForm, incidentLocation: e.target.value })}
                    placeholder="Incident location"
                    required
                    data-testid="input-incident-location"
                  />
                </div>
                
                <div>
                  <Label htmlFor="incident-time">Time</Label>
                  <Input
                    id="incident-time"
                    type="datetime-local"
                    value={new Date(efirForm.incidentDateTime).toISOString().slice(0, 16)}
                    onChange={(e) => setEfirForm({ ...efirForm, incidentDateTime: new Date(e.target.value) })}
                    required
                    data-testid="input-incident-time"
                  />
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={generateEFIRMutation.isPending}
                data-testid="button-generate-efir"
              >
                {generateEFIRMutation.isPending ? (
                  <>
                    <RefreshCw className="mr-2 animate-spin" size={16} />
                    Generating E-FIR...
                  </>
                ) : (
                  <>
                    <Bot className="mr-2" size={16} />
                    Generate E-FIR with AI
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Alerts Table */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Recent SOS Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-4 font-medium">Time</th>
                  <th className="text-left p-4 font-medium">Tourist</th>
                  <th className="text-left p-4 font-medium">Type</th>
                  <th className="text-left p-4 font-medium">Location</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sosAlerts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-4 text-center text-muted-foreground">
                      No SOS alerts recorded yet
                    </td>
                  </tr>
                ) : (
                  sosAlerts.slice(0, 10).map((alert) => (
                    <tr key={alert.id} className="border-b border-border">
                      <td className="p-4" data-testid={`text-alert-time-${alert.id}`}>
                        {alert.createdAt ? new Date(alert.createdAt).toLocaleTimeString() : 'Unknown'}
                      </td>
                      <td className="p-4" data-testid={`text-alert-tourist-${alert.id}`}>
                        Tourist #{alert.userId.slice(-6)}
                      </td>
                      <td className="p-4">
                        <Badge 
                          className={`text-xs font-medium ${getServiceColor(alert.serviceType)}`}
                          data-testid={`badge-service-type-${alert.id}`}
                        >
                          {alert.serviceType}
                        </Badge>
                      </td>
                      <td className="p-4" data-testid={`text-alert-location-${alert.id}`}>
                        {alert.location || 'Unknown location'}
                      </td>
                      <td className="p-4">
                        <Badge 
                          className={`text-xs font-medium ${getStatusColor(alert.status)}`}
                          data-testid={`badge-alert-status-${alert.id}`}
                        >
                          {alert.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-primary hover:underline"
                          data-testid={`button-view-alert-${alert.id}`}
                        >
                          View
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* E-FIR Modal */}
      {showEFIRModal && generatedEFIR && (
        <EFIRModal
          efir={generatedEFIR}
          onClose={() => {
            setShowEFIRModal(false);
            setGeneratedEFIR(null);
          }}
        />
      )}
    </div>
  );
}
