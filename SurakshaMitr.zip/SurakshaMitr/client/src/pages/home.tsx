import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Phone, 
  Truck, 
  Flame, 
  Heart, 
  MapPin, 
  AlertTriangle,
  Users,
  ChevronRight
} from "lucide-react";
import { getStoredUser } from "@/lib/storage";
import SOSModal from "@/components/modals/sos-modal";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const user = getStoredUser();
  const { toast } = useToast();
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [showSOSModal, setShowSOSModal] = useState(false);

  const shareLocationMutation = useMutation({
    mutationFn: async () => {
      return new Promise<void>((resolve) => {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              const { latitude, longitude } = position.coords;
              const message = `LOCATION SHARE: I'm at https://maps.google.com/?q=${latitude},${longitude} - Shared via SurakshaMitr`;
              
              // Share via SMS to emergency contacts
              if (user?.emergencyContacts?.length) {
                const contact = user.emergencyContacts[0];
                window.open(`sms:${contact.countryCode}${contact.mobile}?body=${encodeURIComponent(message)}`);
              } else {
                // Show sharing options
                navigator.share?.({
                  title: 'My Current Location',
                  text: message,
                }) || (navigator.clipboard.writeText(message));
              }
              resolve();
            },
            () => resolve()
          );
        } else {
          resolve();
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Location Shared",
        description: "Your current location has been shared with your emergency contacts.",
      });
    },
  });

  const panicModeAlert = () => {
    toast({
      title: "Panic Mode Activated",
      description: "Silent alert sent to your emergency contacts. Help is on the way.",
      variant: "destructive",
    });
    
    // Send location to emergency contacts
    shareLocationMutation.mutate();
  };

  const handleSOSClick = (serviceType: string) => {
    setSelectedService(serviceType);
    setShowSOSModal(true);
  };

  const sosServices = [
    {
      type: "police",
      title: "Police Emergency",
      description: "Immediate police assistance",
      icon: Shield,
      color: "bg-red-600 hover:bg-red-700",
    },
    {
      type: "ambulance", 
      title: "Medical Emergency",
      description: "Ambulance & medical aid",
      icon: Heart,
      color: "bg-red-500 hover:bg-red-600",
    },
    {
      type: "fire",
      title: "Fire Emergency", 
      description: "Fire department assistance",
      icon: Flame,
      color: "bg-orange-600 hover:bg-orange-700",
    },
    {
      type: "women",
      title: "Women/Child Helpline",
      description: "Specialized support services", 
      icon: Users,
      color: "bg-purple-600 hover:bg-purple-700",
    },
  ];

  return (
    <div className="p-6 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 pt-4">
        <div>
          <h1 className="text-2xl font-bold text-primary" data-testid="text-app-title">SurakshaMitr</h1>
          <p className="text-sm text-muted-foreground" data-testid="text-current-location">
            Current Location: Mumbai, India
          </p>
        </div>
        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
          <span className="text-primary-foreground font-bold" data-testid="text-user-initials">
            {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
          </span>
        </div>
      </div>
      
      {/* Emergency Status Card */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex items-center mb-4">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-3 animate-pulse" />
            <span className="font-medium" data-testid="text-safety-status">Safety Status: Secure</span>
          </div>
          <p className="text-sm text-muted-foreground">
            All emergency services are available in your area
          </p>
        </CardContent>
      </Card>
      
      {/* Emergency SOS Buttons */}
      <div className="space-y-4 mb-8">
        <h2 className="text-xl font-semibold mb-4">Emergency Services</h2>
        
        {sosServices.map((service) => {
          const Icon = service.icon;
          return (
            <Button
              key={service.type}
              onClick={() => handleSOSClick(service.type)}
              className={`w-full p-6 rounded-xl font-bold text-lg flex items-center justify-between h-auto text-white ${service.color} transition-colors`}
              data-testid={`button-sos-${service.type}`}
            >
              <div className="flex items-center">
                <Icon className="text-2xl mr-4" size={32} />
                <div className="text-left">
                  <div>{service.title}</div>
                  <div className="text-sm font-normal opacity-90">{service.description}</div>
                </div>
              </div>
              <ChevronRight size={20} />
            </Button>
          );
        })}
      </div>
      
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          variant="ghost" 
          className="bg-card border border-border p-4 rounded-xl text-center hover:bg-muted transition-colors h-auto flex-col"
          onClick={() => shareLocationMutation.mutate()}
          disabled={shareLocationMutation.isPending}
          data-testid="button-share-location"
        >
          <MapPin className="text-2xl text-primary mb-2" size={32} />
          <div className="font-medium">Share Location</div>
          <div className="text-xs text-muted-foreground">Send to emergency contacts</div>
        </Button>
        
        <Button
          variant="ghost"
          className="bg-card border border-border p-4 rounded-xl text-center hover:bg-muted transition-colors h-auto flex-col"
          onClick={panicModeAlert}
          data-testid="button-panic-mode"
        >
          <AlertTriangle className="text-2xl text-accent mb-2" size={32} />
          <div className="font-medium">Panic Mode</div>
          <div className="text-xs text-muted-foreground">Silent alert to contacts</div>
        </Button>
      </div>

      {/* SOS Modal */}
      {showSOSModal && selectedService && (
        <SOSModal
          serviceType={selectedService}
          onClose={() => {
            setShowSOSModal(false);
            setSelectedService(null);
          }}
        />
      )}
    </div>
  );
}
