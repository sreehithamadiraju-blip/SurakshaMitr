import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, X } from "lucide-react";

declare global {
  interface Window {
    google: any;
  }
}

export default function Map() {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [showRiskAlert, setShowRiskAlert] = useState(false);
  
  useEffect(() => {
    // Initialize Google Maps
    const initMap = () => {
      if (!window.google || !mapRef.current) return;
      
      const mumbaiCenter = { lat: 19.0760, lng: 72.8777 };
      
      const newMap = new window.google.maps.Map(mapRef.current, {
        zoom: 12,
        center: mumbaiCenter,
        mapTypeId: 'roadmap',
      });
      
      // Add user location marker
      new window.google.maps.Marker({
        position: mumbaiCenter,
        map: newMap,
        title: 'Your Location',
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: '#2979FF',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        }
      });
      
      // Add safe places
      const safePlaces = [
        { lat: 19.0330, lng: 72.8570, title: 'Hospital', type: 'hospital' },
        { lat: 19.1070, lng: 72.8870, title: 'Police Station', type: 'police' },
        { lat: 19.0520, lng: 72.8140, title: 'Fire Station', type: 'fire' },
      ];
      
      safePlaces.forEach(place => {
        new window.google.maps.Marker({
          position: { lat: place.lat, lng: place.lng },
          map: newMap,
          title: place.title,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#3b82f6',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          }
        });
      });
      
      // Add risk zones
      const riskZones = [
        { center: { lat: 19.0300, lng: 72.8400 }, radius: 1000, color: '#fbbf24' }, // Yellow
        { center: { lat: 19.1200, lng: 72.9100 }, radius: 800, color: '#ef4444' },  // Red
      ];
      
      riskZones.forEach(zone => {
        new window.google.maps.Circle({
          strokeColor: zone.color,
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: zone.color,
          fillOpacity: 0.15,
          map: newMap,
          center: zone.center,
          radius: zone.radius,
        });
      });
      
      setMap(newMap);
    };
    
    if (window.google) {
      initMap();
    } else {
      // Poll for Google Maps to load
      const checkGoogle = setInterval(() => {
        if (window.google) {
          clearInterval(checkGoogle);
          initMap();
        }
      }, 100);
      
      return () => clearInterval(checkGoogle);
    }
    
    // Simulate entering high risk zone after 3 seconds
    const timer = setTimeout(() => {
      setShowRiskAlert(true);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleSendSOS = () => {
    setShowRiskAlert(false);
    // This would typically trigger the SOS system
    alert("SOS Alert sent to emergency services!");
  };

  return (
    <div className="h-screen relative">
      {/* Map Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-card/90 backdrop-blur-sm p-4 border-b border-border">
        <h2 className="text-xl font-bold text-center" data-testid="text-map-title">Safety Map</h2>
      </div>
      
      {/* Map Container */}
      <div 
        ref={mapRef}
        className="w-full h-full" 
        data-testid="map-container"
        style={{ marginTop: '72px', marginBottom: '160px' }}
      />
      
      {/* Map Legend */}
      <div className="absolute bottom-20 left-4 right-4 bg-card/95 backdrop-blur-sm rounded-lg p-4 border border-border">
        <h3 className="font-semibold mb-3" data-testid="text-map-legend">Map Legend</h3>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2" />
            <span>Safe Areas</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2" />
            <span>Caution Areas</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-2" />
            <span>High Risk</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2" />
            <span>Safe Places</span>
          </div>
        </div>
      </div>
      
      {/* High Risk Alert Modal */}
      {showRiskAlert && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" data-testid="modal-risk-alert">
          <Card className="m-4 max-w-sm border-l-4 border-red-500">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <AlertTriangle className="text-red-500 text-2xl mr-3" size={32} />
                <h3 className="font-bold text-lg">High Risk Area Alert</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                You have entered a high-risk zone. Please remain alert and consider moving to a safer area.
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-red-500 hover:bg-red-600 text-white" 
                  onClick={handleSendSOS}
                  data-testid="button-send-sos-alert"
                >
                  Send SOS
                </Button>
                <Button 
                  variant="ghost" 
                  className="flex-1" 
                  onClick={() => setShowRiskAlert(false)}
                  data-testid="button-dismiss-alert"
                >
                  Dismiss
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
