import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  QrCode, 
  Edit, 
  Plus, 
  Globe, 
  Shield, 
  HelpCircle,
  ChevronRight
} from "lucide-react";
import { getStoredUser, updateStoredUser } from "@/lib/storage";
import { generateQRCode } from "@/lib/qr-generator";
import { useToast } from "@/hooks/use-toast";
import type { EmergencyContact } from "@shared/schema";

export default function Profile() {
  const [user, setUser] = useState(getStoredUser());
  const [showQR, setShowQR] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("");
  const { toast } = useToast();

  const handleShowQR = async () => {
    if (!user) return;
    
    try {
      const qrData = JSON.stringify({
        digitalId: user.digitalId,
        name: user.name,
        mobile: `${user.countryCode}${user.mobile}`,
        idType: user.idType,
        verified: user.isVerified,
      });
      
      const qrUrl = await generateQRCode(qrData);
      setQrCodeUrl(qrUrl);
      setShowQR(true);
    } catch (error) {
      toast({
        title: "QR Code Generation Failed",
        description: "Unable to generate QR code. Please try again.",
        variant: "destructive",
      });
    }
  };

  const addEmergencyContact = (contact: Omit<EmergencyContact, 'id'>) => {
    if (!user) return;
    
    const newContact: EmergencyContact = {
      ...contact,
      id: Math.random().toString(36).substr(2, 9),
    };
    
    const updatedContacts = [...(user.emergencyContacts || []), newContact];
    const updatedUser = { ...user, emergencyContacts: updatedContacts };
    
    setUser(updatedUser);
    updateStoredUser(updatedUser);
    setShowAddContact(false);
    
    toast({
      title: "Contact Added",
      description: "Emergency contact has been added successfully.",
    });
  };

  if (!user) {
    return (
      <div className="p-6 pb-20">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No user profile found. Please register first.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 pb-20">
      <h2 className="text-2xl font-bold mb-6" data-testid="text-profile-title">Digital Tourist ID</h2>
      
      {/* Digital ID Card */}
      <Card className="bg-gradient-to-br from-primary to-blue-600 text-white mb-6">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-lg" data-testid="text-user-name">{user.name}</h3>
              <p className="text-blue-100" data-testid="text-digital-id">TID: {user.digitalId}</p>
            </div>
            <Button
              onClick={handleShowQR}
              className="w-16 h-16 bg-white rounded-lg flex items-center justify-center hover:bg-gray-100 p-0"
              variant="ghost"
              data-testid="button-qr-code"
            >
              <QrCode className="text-gray-800" size={32} />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-blue-200">Mobile</p>
              <p className="font-medium" data-testid="text-user-mobile">
                {user.countryCode} {user.mobile}
              </p>
            </div>
            <div>
              <p className="text-blue-200">ID Type</p>
              <p className="font-medium" data-testid="text-user-id-type">
                {user.idType === 'aadhar' ? 'Aadhar' : 'Passport'}
              </p>
            </div>
            <div>
              <p className="text-blue-200">Status</p>
              <div className="flex items-center">
                <div className={`w-2 h-2 rounded-full mr-2 ${user.isVerified ? 'bg-green-400' : 'bg-yellow-400'}`} />
                <p className="font-medium" data-testid="text-verification-status">
                  {user.isVerified ? 'Verified' : 'Pending'}
                </p>
              </div>
            </div>
            <div>
              <p className="text-blue-200">Valid Until</p>
              <p className="font-medium">Dec 2024</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Profile Actions */}
      <div className="space-y-4 mb-8">
        <Button 
          variant="ghost" 
          className="w-full bg-card border border-border p-4 rounded-lg flex items-center justify-between hover:bg-muted transition-colors h-auto"
          data-testid="button-edit-profile"
        >
          <div className="flex items-center">
            <Edit className="text-primary mr-3" size={20} />
            <span className="font-medium">Edit Profile Information</span>
          </div>
          <ChevronRight className="text-muted-foreground" size={16} />
        </Button>
        
        <Button 
          variant="ghost"
          onClick={handleShowQR}
          className="w-full bg-card border border-border p-4 rounded-lg flex items-center justify-between hover:bg-muted transition-colors h-auto"
          data-testid="button-show-qr-full"
        >
          <div className="flex items-center">
            <QrCode className="text-primary mr-3" size={20} />
            <span className="font-medium">Show QR Code</span>
          </div>
          <ChevronRight className="text-muted-foreground" size={16} />
        </Button>
      </div>
      
      {/* Emergency Contacts */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold" data-testid="text-emergency-contacts-title">Emergency Contacts</h3>
          <Dialog open={showAddContact} onOpenChange={setShowAddContact}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-contact">
                <Plus className="mr-2" size={16} />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Emergency Contact</DialogTitle>
              </DialogHeader>
              <AddContactForm onAdd={addEmergencyContact} />
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="space-y-3">
          {user.emergencyContacts && user.emergencyContacts.length > 0 ? (
            user.emergencyContacts.map((contact) => (
              <Card key={contact.id} className="border">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                      <span className="text-primary-foreground font-bold text-sm">
                        {contact.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium" data-testid={`text-contact-name-${contact.id}`}>
                        {contact.name}
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`text-contact-details-${contact.id}`}>
                        {contact.relationship} • {contact.countryCode} {contact.mobile}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" data-testid={`button-edit-contact-${contact.id}`}>
                    <Edit size={16} />
                  </Button>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-muted-foreground" data-testid="text-no-contacts">
                  No emergency contacts added yet.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      {/* Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold mb-4">Settings</h3>
        
        <Button 
          variant="ghost"
          className="w-full bg-card border border-border p-4 rounded-lg flex items-center justify-between hover:bg-muted transition-colors h-auto"
          data-testid="button-change-language"
        >
          <div className="flex items-center">
            <Globe className="text-primary mr-3" size={20} />
            <span className="font-medium">Change Language</span>
          </div>
          <div className="flex items-center">
            <span className="text-sm text-muted-foreground mr-2">English</span>
            <ChevronRight className="text-muted-foreground" size={16} />
          </div>
        </Button>
        
        <Button 
          variant="ghost"
          className="w-full bg-card border border-border p-4 rounded-lg flex items-center justify-between hover:bg-muted transition-colors h-auto"
          data-testid="button-privacy-settings"
        >
          <div className="flex items-center">
            <Shield className="text-primary mr-3" size={20} />
            <span className="font-medium">Privacy & Security</span>
          </div>
          <ChevronRight className="text-muted-foreground" size={16} />
        </Button>
        
        <Button 
          variant="ghost"
          className="w-full bg-card border border-border p-4 rounded-lg flex items-center justify-between hover:bg-muted transition-colors h-auto"
          data-testid="button-help-support"
        >
          <div className="flex items-center">
            <HelpCircle className="text-primary mr-3" size={20} />
            <span className="font-medium">Help & Support</span>
          </div>
          <ChevronRight className="text-muted-foreground" size={16} />
        </Button>
      </div>

      {/* QR Code Modal */}
      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Digital Tourist ID</DialogTitle>
          </DialogHeader>
          <div className="text-center py-4">
            {qrCodeUrl && (
              <img 
                src={qrCodeUrl} 
                alt="Digital Tourist ID QR Code"
                className="w-64 h-64 mx-auto mb-4"
                data-testid="img-qr-code"
              />
            )}
            <p className="text-sm text-muted-foreground">
              Scan this QR code to verify your Digital Tourist ID
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Add Contact Form Component
function AddContactForm({ onAdd }: { onAdd: (contact: Omit<EmergencyContact, 'id'>) => void }) {
  const [formData, setFormData] = useState({
    name: "",
    relationship: "",
    countryCode: "+91",
    mobile: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.mobile && formData.relationship) {
      onAdd(formData);
      setFormData({ name: "", relationship: "", countryCode: "+91", mobile: "" });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="contact-name">Name</Label>
        <Input
          id="contact-name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Enter contact name"
          required
          data-testid="input-contact-name"
        />
      </div>
      
      <div>
        <Label htmlFor="contact-relationship">Relationship</Label>
        <Input
          id="contact-relationship"
          value={formData.relationship}
          onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
          placeholder="e.g., Father, Sister, Friend"
          required
          data-testid="input-contact-relationship"
        />
      </div>
      
      <div>
        <Label htmlFor="contact-mobile">Mobile Number</Label>
        <div className="flex">
          <select
            value={formData.countryCode}
            onChange={(e) => setFormData({ ...formData, countryCode: e.target.value })}
            className="p-3 border border-border rounded-l-md bg-background"
            data-testid="select-contact-country-code"
          >
            <option value="+91">+91</option>
            <option value="+1">+1</option>
            <option value="+44">+44</option>
            <option value="+33">+33</option>
          </select>
          <Input
            id="contact-mobile"
            value={formData.mobile}
            onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
            placeholder="Enter mobile number"
            className="rounded-l-none"
            required
            data-testid="input-contact-mobile"
          />
        </div>
      </div>
      
      <Button type="submit" className="w-full" data-testid="button-save-contact">
        Add Contact
      </Button>
    </form>
  );
}
