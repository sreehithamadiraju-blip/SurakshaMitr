import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";
import { getStoredUser } from "@/lib/storage";
import { LANGUAGES } from "@/lib/languages";

export default function Welcome() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Check if user is already registered
    const storedUser = getStoredUser();
    if (storedUser) {
      navigate("/home");
    }
  }, [navigate]);

  const handleLanguageSelect = (langCode: string) => {
    localStorage.setItem("selectedLanguage", langCode);
    navigate("/onboarding");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background">
      <div className="text-center mb-8">
        <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
          <Shield className="text-4xl text-primary-foreground" size={48} />
        </div>
        <h1 className="text-4xl font-bold text-primary mb-2">SurakshaMitr</h1>
        <p className="text-lg text-muted-foreground">Your Smart Safety Companion</p>
      </div>
      
      <div className="w-full max-w-md space-y-4 mb-8">
        <h2 className="text-xl font-semibold text-center mb-6">Select Your Language</h2>
        
        {LANGUAGES.map((language) => (
          <Button
            key={language.code}
            onClick={() => handleLanguageSelect(language.code)}
            className="w-full p-4 bg-card border border-border rounded-lg hover:bg-muted transition-colors text-left flex items-center justify-between h-auto"
            variant="ghost"
            data-testid={`button-select-language-${language.code}`}
          >
            <div className="flex items-center">
              <span className="text-2xl mr-3">{language.flag}</span>
              <span className="font-medium">{language.name}</span>
            </div>
            <i className="fas fa-chevron-right text-muted-foreground" />
          </Button>
        ))}
      </div>
    </div>
  );
}
