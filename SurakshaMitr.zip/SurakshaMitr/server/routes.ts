import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertSOSAlertSchema, insertEFIRSchema } from "@shared/schema";
import { z } from "zod";
import { generateEFIR } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.json({ success: true, user });
    } catch (error) {
      res.status(400).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get("/api/users/:digitalId", async (req, res) => {
    try {
      const user = await storage.getUserByDigitalId(req.params.digitalId);
      if (!user) {
        return res.status(404).json({ success: false, error: "User not found" });
      }
      res.json({ success: true, user });
    } catch (error) {
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ success: false, error: "User not found" });
      }
      res.json({ success: true, user });
    } catch (error) {
      res.status(400).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // SOS Alert routes
  app.post("/api/sos-alerts", async (req, res) => {
    try {
      const validatedData = insertSOSAlertSchema.parse(req.body);
      const alert = await storage.createSOSAlert(validatedData);
      res.json({ success: true, alert });
    } catch (error) {
      res.status(400).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get("/api/sos-alerts", async (req, res) => {
    try {
      const alerts = await storage.getAllSOSAlerts();
      res.json({ success: true, alerts });
    } catch (error) {
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put("/api/sos-alerts/:id", async (req, res) => {
    try {
      const alert = await storage.updateSOSAlert(req.params.id, req.body);
      if (!alert) {
        return res.status(404).json({ success: false, error: "Alert not found" });
      }
      res.json({ success: true, alert });
    } catch (error) {
      res.status(400).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Alert routes
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getAllAlerts();
      res.json({ success: true, alerts });
    } catch (error) {
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // E-FIR routes
  app.post("/api/efirs", async (req, res) => {
    try {
      const validatedData = insertEFIRSchema.parse(req.body);
      
      // Generate E-FIR content using AI
      const aiContent = await generateEFIR({
        touristName: validatedData.touristName,
        touristId: validatedData.touristId,
        incidentLocation: validatedData.incidentLocation,
        incidentDateTime: validatedData.incidentDateTime,
        incidentSummary: validatedData.incidentSummary,
        officerName: validatedData.officerName || undefined,
        officerBadge: validatedData.officerBadge || undefined,
        policeStation: validatedData.policeStation || undefined,
      });
      
      const efir = await storage.createEFIR({
        ...validatedData,
        content: aiContent,
      });
      
      res.json({ success: true, efir });
    } catch (error) {
      res.status(400).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get("/api/efirs", async (req, res) => {
    try {
      const efirs = await storage.getAllEFIRs();
      res.json({ success: true, efirs });
    } catch (error) {
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get("/api/efirs/:id", async (req, res) => {
    try {
      const efir = await storage.getEFIR(req.params.id);
      if (!efir) {
        return res.status(404).json({ success: false, error: "E-FIR not found" });
      }
      res.json({ success: true, efir });
    } catch (error) {
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
