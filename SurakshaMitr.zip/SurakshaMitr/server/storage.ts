import { 
  type User, 
  type InsertUser, 
  type SOSAlert, 
  type InsertSOSAlert,
  type Alert,
  type InsertAlert,
  type EFIR,
  type InsertEFIR,
  type EmergencyContact
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByDigitalId(digitalId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // SOS Alert methods
  getSOSAlert(id: string): Promise<SOSAlert | undefined>;
  getSOSAlertsByUser(userId: string): Promise<SOSAlert[]>;
  getAllSOSAlerts(): Promise<SOSAlert[]>;
  createSOSAlert(alert: InsertSOSAlert): Promise<SOSAlert>;
  updateSOSAlert(id: string, updates: Partial<SOSAlert>): Promise<SOSAlert | undefined>;
  
  // Alert methods
  getAllAlerts(): Promise<Alert[]>;
  getActiveAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  
  // E-FIR methods
  getEFIR(id: string): Promise<EFIR | undefined>;
  getAllEFIRs(): Promise<EFIR[]>;
  createEFIR(efir: InsertEFIR & { content: string }): Promise<EFIR>;
  updateEFIR(id: string, updates: Partial<EFIR>): Promise<EFIR | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private sosAlerts: Map<string, SOSAlert> = new Map();
  private alerts: Map<string, Alert> = new Map();
  private efirs: Map<string, EFIR> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed some sample alerts
    const sampleAlerts: Alert[] = [
      {
        id: "alert-1",
        type: "scam_warning",
        title: "Fake Taxi Scam Alert - Colaba Area",
        description: "Reports of unauthorized taxis charging excessive fares near Gateway of India. Always verify taxi registration and use official booking apps.",
        location: "Colaba, Mumbai",
        priority: "high",
        isActive: true,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        validUntil: null,
      },
      {
        id: "alert-2", 
        type: "police_bulletin",
        title: "Wanted Individual Alert",
        description: "Be aware: Individual involved in tourist fraud cases spotted in Bandra area. Report any suspicious activity to local authorities immediately.",
        location: "Bandra, Mumbai",
        priority: "critical",
        isActive: true,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        validUntil: null,
      },
      {
        id: "alert-3",
        type: "safety_tip",
        title: "Monsoon Safety Guidelines",
        description: "Avoid low-lying areas during heavy rains. Keep important documents in waterproof bags and maintain emergency contact list.",
        location: null,
        priority: "medium",
        isActive: true,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
        validUntil: null,
      },
      {
        id: "alert-4",
        type: "traffic_update",
        title: "Road Closure - Western Express Highway",
        description: "Temporary road closure due to construction work. Use alternate routes via SV Road or LBS Marg.",
        location: "Western Express Highway, Mumbai",
        priority: "medium",
        isActive: true,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
        validUntil: new Date(Date.now() + 6 * 60 * 60 * 1000), // Valid for 6 more hours
      }
    ];

    sampleAlerts.forEach(alert => this.alerts.set(alert.id, alert));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByDigitalId(digitalId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.digitalId === digitalId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const digitalId = `SM-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;
    
    const user: User = {
      ...insertUser,
      id,
      digitalId,
      countryCode: insertUser.countryCode || "+91",
      emergencyContacts: insertUser.emergencyContacts || [],
      isVerified: true, // Auto-verify for demo
      createdAt: new Date(),
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // SOS Alert methods
  async getSOSAlert(id: string): Promise<SOSAlert | undefined> {
    return this.sosAlerts.get(id);
  }

  async getSOSAlertsByUser(userId: string): Promise<SOSAlert[]> {
    return Array.from(this.sosAlerts.values()).filter(alert => alert.userId === userId);
  }

  async getAllSOSAlerts(): Promise<SOSAlert[]> {
    return Array.from(this.sosAlerts.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async createSOSAlert(insertAlert: InsertSOSAlert): Promise<SOSAlert> {
    const id = randomUUID();
    const alert: SOSAlert = {
      ...insertAlert,
      id,
      status: insertAlert.status || "active",
      location: insertAlert.location || null,
      coordinates: insertAlert.coordinates || null,
      response: insertAlert.response || null,
      createdAt: new Date(),
      resolvedAt: null,
    };
    
    this.sosAlerts.set(id, alert);
    return alert;
  }

  async updateSOSAlert(id: string, updates: Partial<SOSAlert>): Promise<SOSAlert | undefined> {
    const alert = this.sosAlerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, ...updates };
    this.sosAlerts.set(id, updatedAlert);
    return updatedAlert;
  }

  // Alert methods
  async getAllAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.isActive)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return this.getAllAlerts();
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = {
      ...insertAlert,
      id,
      location: insertAlert.location || null,
      priority: insertAlert.priority || "medium",
      isActive: insertAlert.isActive !== false, // default to true unless explicitly false
      createdAt: new Date(),
      validUntil: null,
    };
    
    this.alerts.set(id, alert);
    return alert;
  }

  // E-FIR methods
  async getEFIR(id: string): Promise<EFIR | undefined> {
    return this.efirs.get(id);
  }

  async getAllEFIRs(): Promise<EFIR[]> {
    return Array.from(this.efirs.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async createEFIR(insertEFIR: InsertEFIR & { content: string }): Promise<EFIR> {
    const id = randomUUID();
    const firNumber = `FIR-${new Date().getFullYear()}-${String(this.efirs.size + 1).padStart(6, '0')}`;
    
    const efir: EFIR = {
      ...insertEFIR,
      id,
      firNumber,
      status: "draft", // default status
      officerName: insertEFIR.officerName || null,
      officerBadge: insertEFIR.officerBadge || null,
      policeStation: insertEFIR.policeStation || null,
      createdAt: new Date(),
    };
    
    this.efirs.set(id, efir);
    return efir;
  }

  async updateEFIR(id: string, updates: Partial<EFIR>): Promise<EFIR | undefined> {
    const efir = this.efirs.get(id);
    if (!efir) return undefined;
    
    const updatedEFIR = { ...efir, ...updates };
    this.efirs.set(id, updatedEFIR);
    return updatedEFIR;
  }
}

export const storage = new MemStorage();
