import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  digitalId: text("digital_id").notNull().unique(),
  name: text("name").notNull(),
  mobile: text("mobile").notNull(),
  countryCode: text("country_code").notNull().default("+91"),
  idType: text("id_type").notNull(), // 'aadhar' or 'passport'
  idNumber: text("id_number").notNull(),
  language: text("language").notNull().default("en"),
  isVerified: boolean("is_verified").default(false),
  emergencyContacts: json("emergency_contacts").$type<EmergencyContact[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sosAlerts = pgTable("sos_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  serviceType: text("service_type").notNull(), // 'police', 'ambulance', 'fire', 'women'
  location: text("location"),
  coordinates: json("coordinates").$type<{lat: number, lng: number}>(),
  status: text("status").notNull().default("active"), // 'active', 'in_progress', 'resolved'
  response: text("response"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'scam_warning', 'police_bulletin', 'safety_tip', 'traffic_update'
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location"),
  priority: text("priority").notNull().default("medium"), // 'low', 'medium', 'high', 'critical'
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  validUntil: timestamp("valid_until"),
});

export const efirs = pgTable("efirs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firNumber: text("fir_number").notNull().unique(),
  touristName: text("tourist_name").notNull(),
  touristId: text("tourist_id").notNull(),
  incidentLocation: text("incident_location").notNull(),
  incidentDateTime: timestamp("incident_date_time").notNull(),
  incidentSummary: text("incident_summary").notNull(),
  officerName: text("officer_name"),
  officerBadge: text("officer_badge"),
  policeStation: text("police_station"),
  content: text("content").notNull(), // AI-generated markdown content
  status: text("status").notNull().default("draft"), // 'draft', 'filed', 'processed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  digitalId: true,
  createdAt: true,
}).extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  mobile: z.string().min(10, "Mobile number must be at least 10 digits"),
  idNumber: z.string().min(5, "ID number must be at least 5 characters"),
  idType: z.enum(["aadhar", "passport"]),
  language: z.string().default("en"),
});

export const insertSOSAlertSchema = createInsertSchema(sosAlerts).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertEFIRSchema = createInsertSchema(efirs).omit({
  id: true,
  firNumber: true,
  content: true,
  createdAt: true,
}).extend({
  touristName: z.string().min(2, "Tourist name is required"),
  touristId: z.string().min(5, "Tourist ID is required"),
  incidentLocation: z.string().min(2, "Incident location is required"),
  incidentSummary: z.string().min(10, "Incident summary must be detailed"),
});

export interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  mobile: string;
  countryCode: string;
}

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSOSAlert = z.infer<typeof insertSOSAlertSchema>;
export type SOSAlert = typeof sosAlerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertEFIR = z.infer<typeof insertEFIRSchema>;
export type EFIR = typeof efirs.$inferSelect;
